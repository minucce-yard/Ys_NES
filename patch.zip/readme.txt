Ys - Service Repair


Latest:
2021-10-09



//////////////////////////////////////////////////////////////////



Patching:


-  Ys (Japan).nes

   MD-5:  96BC9E45F3986A8281D799690B3C3A12
   SHA-1: 0F940EF923B43C1821F9ABB4DCA642527FA04A8F



-  Optional patch:

   *  English  (David Mullen / MakoKnight)
      https://www.romhacking.net/translations/238/



-  Choose patch:

   * basic.ips
   * plus.ips



___________________________________________________



Basic:


hud_split
*  Fix status bar border



pixel_cleanup
*  Fix stray mouth pixel on title screen



screen_switch
*  Fix V-Blank waiting problems



scroll_border
*  Fix scanline scrolling visual errors



sprite_border
*  Fix sprite clipping at hud border



start_hud
*  Fix graphics corruption when starting new game



___________________________________________________



Plus:


deadzone_scroll
*  Scroll game window earlier



___________________________________________________



Commits:


7.1 - scroll_border updated
    *  Fix crash on pixel 255


7 - deadzone_scroll released


6.1 - scroll_border updated
    *  Fix right-side screen  (original)


6 - start_hud released


5 - screen_switch released


4 - scroll_border released


3 - sprite_border released


2 - hud_split released


1 - pixel_cleanup released



_______________________________________________



Visit:


*  Source code
   https://github.com/minucce-yard/Ys_NES/tree/Service_Repair



_________________________________________________________



Comments:


*  Cheats

  358 = hp
  359 = max hp

  35a-35b = exp
  35c-35d = max exp
